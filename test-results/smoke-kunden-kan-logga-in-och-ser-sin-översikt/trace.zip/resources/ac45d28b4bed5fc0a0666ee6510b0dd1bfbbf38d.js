import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.vue?vue&type=style&index=0&lang.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "C:/Users/bonga/Desktop/CHAS Plugg/Projekt/Grupparbeten/Kraftly/Kraftly/Team-Ampere/src/App.vue?vue&type=style&index=0&lang.css"
const __vite__css = "\n.topbar { background: #101d3d;\n}\n.topbar-inner { display: flex; align-items: center; justify-content: space-between; padding-top: 14px; padding-bottom: 14px;\n}\n.logo { height: 30px;\n}\n.topbar nav a, .logout {\r\n  color: #c2cbe4;\r\n  text-decoration: none;\r\n  margin-left: 22px;\r\n  font-size: 14.5px;\r\n  cursor: pointer;\n}\n.topbar nav a.router-link-active { color: #fff; font-weight: 600;\n}\r\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))