import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AppButton.vue");
// new button for the profile page, the old one couldn't be themed /J
// TODO merge with BaseButton some day
const _sfc_main = {
  name: 'AppButton',
  props: { color: { type: String, default: '#2f54eb' } }
}

import { renderSlot as _renderSlot, normalizeStyle as _normalizeStyle, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=d70ec34b"

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("button", {
    class: "app-btn",
    style: _normalizeStyle({ background: $props.color })
  }, [
    _renderSlot(_ctx.$slots, "default", {}, undefined, true)
  ], 4 /* STYLE */))
}

import "/src/components/AppButton.vue?vue&type=style&index=0&scoped=19765ba3&lang.css"

_sfc_main.__hmrId = "19765ba3"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-19765ba3"],['__file',"C:/Users/bonga/Desktop/CHAS Plugg/Projekt/Grupparbeten/Kraftly/Kraftly/Team-Ampere/src/components/AppButton.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQzovVXNlcnMvYm9uZ2EvRGVza3RvcC9DSEFTIFBsdWdnL1Byb2pla3QvR3J1cHBhcmJldGVuL0tyYWZ0bHkvS3JhZnRseS9UZWFtLUFtcGVyZS9zcmMvY29tcG9uZW50cy9BcHBCdXR0b24udnVlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcEJ1dHRvbi52dWUiXSwic291cmNlc0NvbnRlbnQiOlsiPHRlbXBsYXRlPlxyXG4gIDxidXR0b24gY2xhc3M9XCJhcHAtYnRuXCIgOnN0eWxlPVwieyBiYWNrZ3JvdW5kOiBjb2xvciB9XCI+PHNsb3QgLz48L2J1dHRvbj5cclxuPC90ZW1wbGF0ZT5cclxuXHJcbjxzY3JpcHQ+XHJcbi8vIG5ldyBidXR0b24gZm9yIHRoZSBwcm9maWxlIHBhZ2UsIHRoZSBvbGQgb25lIGNvdWxkbid0IGJlIHRoZW1lZCAvSlxyXG4vLyBUT0RPIG1lcmdlIHdpdGggQmFzZUJ1dHRvbiBzb21lIGRheVxyXG5leHBvcnQgZGVmYXVsdCB7XHJcbiAgbmFtZTogJ0FwcEJ1dHRvbicsXHJcbiAgcHJvcHM6IHsgY29sb3I6IHsgdHlwZTogU3RyaW5nLCBkZWZhdWx0OiAnIzJmNTRlYicgfSB9XHJcbn1cclxuPC9zY3JpcHQ+XHJcblxyXG48c3R5bGUgc2NvcGVkPlxyXG4uYXBwLWJ0biB7IGJvcmRlcjogMDsgY29sb3I6IHdoaXRlOyBwYWRkaW5nOiAxMXB4IDIwcHg7IGJvcmRlci1yYWRpdXM6IDhweDsgZm9udC1zaXplOiAxNXB4OyBjdXJzb3I6IHBvaW50ZXI7IH1cclxuPC9zdHlsZT5cclxuIl0sIm1hcHBpbmdzIjoiO0FBS0EsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNwRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7RUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRTtBQUN2RDs7Ozs7d0JBVEUsb0JBQXdFO0lBQWhFLEtBQUssRUFBQyxTQUFTO0lBQUUsS0FBSyxnQ0FBZ0IsWUFBSzs7SUFBSSxZQUFRIiwiaWdub3JlTGlzdCI6W119