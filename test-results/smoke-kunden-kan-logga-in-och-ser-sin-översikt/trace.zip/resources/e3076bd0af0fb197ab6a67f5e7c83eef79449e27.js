import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/InvoicesView.vue");import { ref, onMounted } from "/node_modules/.vite/deps/vue.js?v=d70ec34b"
import { fetchInvoices } from "/src/services/api.js"


const _sfc_main = {
  __name: 'InvoicesView',
  setup(__props, { expose: __expose }) {
  __expose();

const invoices = ref([])

onMounted(async () => {
  invoices.value = await fetchInvoices()
})

const downloadInvoice = (invoice) => {
  // PDF generation coming in phase 2 per the quote
  console.log('download', invoice.id)
  alert('Nedladdning kommer snart')
}

const __returned__ = { invoices, downloadInvoice, ref, onMounted, get fetchInvoices() { return fetchInvoices } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createElementVNode as _createElementVNode, renderList as _renderList, Fragment as _Fragment, openBlock as _openBlock, createElementBlock as _createElementBlock, toDisplayString as _toDisplayString, normalizeClass as _normalizeClass } from "/node_modules/.vite/deps/vue.js?v=d70ec34b"

const _hoisted_1 = { class: "card" }
const _hoisted_2 = ["onClick"]

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("div", null, [
    _cache[1] || (_cache[1] = _createElementVNode("h1", null, "Fakturor", -1 /* CACHED */)),
    _createElementVNode("div", _hoisted_1, [
      _createElementVNode("table", null, [
        _cache[0] || (_cache[0] = _createElementVNode("tr", null, [
          _createElementVNode("th", null, "Faktura"),
          _createElementVNode("th", null, "Period"),
          _createElementVNode("th", null, "Belopp"),
          _createElementVNode("th", null, "Förfaller"),
          _createElementVNode("th", null, "Status"),
          _createElementVNode("th")
        ], -1 /* CACHED */)),
        (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($setup.invoices, (invoice) => {
          return (_openBlock(), _createElementBlock("tr", {
            key: invoice.id
          }, [
            _createElementVNode("td", null, _toDisplayString(invoice.id), 1 /* TEXT */),
            _createElementVNode("td", null, _toDisplayString(invoice.period), 1 /* TEXT */),
            _createElementVNode("td", null, _toDisplayString(invoice.amount) + " kr", 1 /* TEXT */),
            _createElementVNode("td", null, _toDisplayString(invoice.due), 1 /* TEXT */),
            _createElementVNode("td", null, [
              _createElementVNode("span", {
                class: _normalizeClass(['status-chip', invoice.status === 'Betald' ? 'status-betald' : 'status-obetald'])
              }, _toDisplayString(invoice.status), 3 /* TEXT, CLASS */)
            ]),
            _createElementVNode("td", null, [
              _createElementVNode("div", {
                class: "download",
                onClick: $event => ($setup.downloadInvoice(invoice))
              }, "Ladda ner", 8 /* PROPS */, _hoisted_2)
            ])
          ]))
        }), 128 /* KEYED_FRAGMENT */))
      ])
    ])
  ]))
}

import "/src/views/InvoicesView.vue?vue&type=style&index=0&scoped=e2b6ca3d&lang.css"

_sfc_main.__hmrId = "e2b6ca3d"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-e2b6ca3d"],['__file',"C:/Users/bonga/Desktop/CHAS Plugg/Projekt/Grupparbeten/Kraftly/Kraftly/Team-Ampere/src/views/InvoicesView.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSW52b2ljZXNWaWV3LnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XHJcbiAgPGRpdj5cclxuICAgIDxoMT5GYWt0dXJvcjwvaDE+XHJcbiAgICA8ZGl2IGNsYXNzPVwiY2FyZFwiPlxyXG4gICAgICA8dGFibGU+XHJcbiAgICAgICAgPHRyPlxyXG4gICAgICAgICAgPHRoPkZha3R1cmE8L3RoPjx0aD5QZXJpb2Q8L3RoPjx0aD5CZWxvcHA8L3RoPjx0aD5Gw7ZyZmFsbGVyPC90aD48dGg+U3RhdHVzPC90aD48dGg+PC90aD5cclxuICAgICAgICA8L3RyPlxyXG4gICAgICAgIDx0ciB2LWZvcj1cImludm9pY2UgaW4gaW52b2ljZXNcIiA6a2V5PVwiaW52b2ljZS5pZFwiPlxyXG4gICAgICAgICAgPHRkPnt7IGludm9pY2UuaWQgfX08L3RkPlxyXG4gICAgICAgICAgPHRkPnt7IGludm9pY2UucGVyaW9kIH19PC90ZD5cclxuICAgICAgICAgIDx0ZD57eyBpbnZvaWNlLmFtb3VudCB9fSBrcjwvdGQ+XHJcbiAgICAgICAgICA8dGQ+e3sgaW52b2ljZS5kdWUgfX08L3RkPlxyXG4gICAgICAgICAgPHRkPjxzcGFuIDpjbGFzcz1cIlsnc3RhdHVzLWNoaXAnLCBpbnZvaWNlLnN0YXR1cyA9PT0gJ0JldGFsZCcgPyAnc3RhdHVzLWJldGFsZCcgOiAnc3RhdHVzLW9iZXRhbGQnXVwiPnt7IGludm9pY2Uuc3RhdHVzIH19PC9zcGFuPjwvdGQ+XHJcbiAgICAgICAgICA8dGQ+PGRpdiBjbGFzcz1cImRvd25sb2FkXCIgQGNsaWNrPVwiZG93bmxvYWRJbnZvaWNlKGludm9pY2UpXCI+TGFkZGEgbmVyPC9kaXY+PC90ZD5cclxuICAgICAgICA8L3RyPlxyXG4gICAgICA8L3RhYmxlPlxyXG4gICAgPC9kaXY+XHJcbiAgPC9kaXY+XHJcbjwvdGVtcGxhdGU+XHJcblxyXG48c2NyaXB0IHNldHVwPlxyXG5pbXBvcnQgeyByZWYsIG9uTW91bnRlZCB9IGZyb20gJ3Z1ZSdcclxuaW1wb3J0IHsgZmV0Y2hJbnZvaWNlcyB9IGZyb20gJy4uL3NlcnZpY2VzL2FwaSdcclxuXHJcbmNvbnN0IGludm9pY2VzID0gcmVmKFtdKVxyXG5cclxub25Nb3VudGVkKGFzeW5jICgpID0+IHtcclxuICBpbnZvaWNlcy52YWx1ZSA9IGF3YWl0IGZldGNoSW52b2ljZXMoKVxyXG59KVxyXG5cclxuY29uc3QgZG93bmxvYWRJbnZvaWNlID0gKGludm9pY2UpID0+IHtcclxuICAvLyBQREYgZ2VuZXJhdGlvbiBjb21pbmcgaW4gcGhhc2UgMiBwZXIgdGhlIHF1b3RlXHJcbiAgY29uc29sZS5sb2coJ2Rvd25sb2FkJywgaW52b2ljZS5pZClcclxuICBhbGVydCgnTmVkbGFkZG5pbmcga29tbWVyIHNuYXJ0JylcclxufVxyXG48L3NjcmlwdD5cclxuXHJcbjxzdHlsZSBzY29wZWQ+XHJcbi5kb3dubG9hZCB7IGNvbG9yOiAjMmY1NGViOyBjdXJzb3I6IHBvaW50ZXI7IGZvbnQtc2l6ZTogMTRweDsgfVxyXG48L3N0eWxlPlxyXG4iXSwibWFwcGluZ3MiOiJBQXNCQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0M7Ozs7OztBQUhjO0FBSWQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEI7QUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QyxDQUFDLENBQUM7QUFDRjtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQyxDQUFDOzs7Ozs7Ozs7O3FCQWhDUSxLQUFLLEVBQUMsTUFBTTs7Ozt3QkFGbkIsb0JBaUJNOzhCQWhCSixvQkFBaUIsWUFBYixVQUFRO0lBQ1osb0JBY00sT0FkTixVQWNNO01BYkosb0JBWVE7a0NBWE4sb0JBRUs7VUFESCxvQkFBZ0IsWUFBWixTQUFPO1VBQUssb0JBQWUsWUFBWCxRQUFNO1VBQUssb0JBQWUsWUFBWCxRQUFNO1VBQUssb0JBQWtCLFlBQWQsV0FBUztVQUFLLG9CQUFlLFlBQVgsUUFBTTtVQUFLLG9CQUFTOzsyQkFFMUYsb0JBT0ssNkJBUGlCLGVBQVEsR0FBbkIsT0FBTztnQ0FBbEIsb0JBT0s7WUFQNEIsR0FBRyxFQUFFLE9BQU8sQ0FBQyxFQUFFOztZQUM5QyxvQkFBeUIsNkJBQWxCLE9BQU8sQ0FBQyxFQUFFO1lBQ2pCLG9CQUE2Qiw2QkFBdEIsT0FBTyxDQUFDLE1BQU07WUFDckIsb0JBQWdDLDZCQUF6QixPQUFPLENBQUMsTUFBTSxJQUFHLEtBQUc7WUFDM0Isb0JBQTBCLDZCQUFuQixPQUFPLENBQUMsR0FBRztZQUNsQixvQkFBcUk7Y0FBakksb0JBQTRIO2dCQUFySCxLQUFLLGtDQUFrQixPQUFPLENBQUMsTUFBTTtrQ0FBd0QsT0FBTyxDQUFDLE1BQU07O1lBQ3RILG9CQUFnRjtjQUE1RSxvQkFBdUU7Z0JBQWxFLEtBQUssRUFBQyxVQUFVO2dCQUFFLE9BQUssYUFBRSxzQkFBZSxDQUFDLE9BQU87aUJBQUcsV0FBUyIsImlnbm9yZUxpc3QiOltdfQ==