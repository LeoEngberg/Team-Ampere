import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BaseButton.vue");const _sfc_main = {  }
import { createCommentVNode as _createCommentVNode, renderSlot as _renderSlot, createElementVNode as _createElementVNode, Fragment as _Fragment, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=d70ec34b"

const _hoisted_1 = { class: "btn" }

function _sfc_render(_ctx, _cache) {
  return (_openBlock(), _createElementBlock(_Fragment, null, [
    _createCommentVNode(" generic button, use this one! /M "),
    _createElementVNode("button", _hoisted_1, [
      _renderSlot(_ctx.$slots, "default")
    ])
  ], 2112 /* STABLE_FRAGMENT, DEV_ROOT_FRAGMENT */))
}


_sfc_main.__hmrId = "2d3a2488"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/Users/bonga/Desktop/CHAS Plugg/Projekt/Grupparbeten/Kraftly/Kraftly/Team-Ampere/src/components/BaseButton.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQzovVXNlcnMvYm9uZ2EvRGVza3RvcC9DSEFTIFBsdWdnL1Byb2pla3QvR3J1cHBhcmJldGVuL0tyYWZ0bHkvS3JhZnRseS9UZWFtLUFtcGVyZS9zcmMvY29tcG9uZW50cy9CYXNlQnV0dG9uLnZ1ZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJCYXNlQnV0dG9uLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XHJcbiAgPCEtLSBnZW5lcmljIGJ1dHRvbiwgdXNlIHRoaXMgb25lISAvTSAtLT5cclxuICA8YnV0dG9uIGNsYXNzPVwiYnRuXCI+PHNsb3QgLz48L2J1dHRvbj5cclxuPC90ZW1wbGF0ZT5cclxuIl0sIm1hcHBpbmdzIjoiOzs7cUJBRVUsS0FBSyxFQUFDLEtBQUs7Ozs7SUFEbkIseURBQXlDO0lBQ3pDLG9CQUFxQyxVQUFyQyxVQUFxQztNQUFqQixZQUFRIiwiaWdub3JlTGlzdCI6W119