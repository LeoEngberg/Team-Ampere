import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.vue");import { useRouter } from "/node_modules/.vite/deps/vue-router.js?v=671dfeaf"


const _sfc_main = {
  __name: 'App',
  setup(__props, { expose: __expose }) {
  __expose();

const router = useRouter()

const logout = () => {
  localStorage.removeItem('kraftly_logged_in')
  router.push('/login')
}

const __returned__ = { router, logout, get useRouter() { return useRouter } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createElementVNode as _createElementVNode, createTextVNode as _createTextVNode, resolveComponent as _resolveComponent, withCtx as _withCtx, createVNode as _createVNode, openBlock as _openBlock, createElementBlock as _createElementBlock, createCommentVNode as _createCommentVNode } from "/node_modules/.vite/deps/vue.js?v=d70ec34b"

const _hoisted_1 = {
  key: 0,
  class: "topbar"
}
const _hoisted_2 = { class: "topbar-inner container" }
const _hoisted_3 = { class: "container" }

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_RouterLink = _resolveComponent("RouterLink")
  const _component_RouterView = _resolveComponent("RouterView")

  return (_openBlock(), _createElementBlock("div", null, [
    (_ctx.$route.path !== '/login')
      ? (_openBlock(), _createElementBlock("header", _hoisted_1, [
          _createElementVNode("div", _hoisted_2, [
            _cache[4] || (_cache[4] = _createElementVNode("img", {
              src: "/src/assets/logo.svg",
              class: "logo"
            }, null, -1 /* CACHED */)),
            _createElementVNode("nav", null, [
              _createVNode(_component_RouterLink, { to: "/" }, {
                default: _withCtx(() => [...(_cache[0] || (_cache[0] = [
                  _createTextVNode("Översikt", -1 /* CACHED */)
                ]))]),
                _: 1 /* STABLE */
              }),
              _createVNode(_component_RouterLink, { to: "/fakturor" }, {
                default: _withCtx(() => [...(_cache[1] || (_cache[1] = [
                  _createTextVNode("Fakturor", -1 /* CACHED */)
                ]))]),
                _: 1 /* STABLE */
              }),
              _createVNode(_component_RouterLink, { to: "/flytt" }, {
                default: _withCtx(() => [...(_cache[2] || (_cache[2] = [
                  _createTextVNode("Flyttanmälan", -1 /* CACHED */)
                ]))]),
                _: 1 /* STABLE */
              }),
              _createVNode(_component_RouterLink, { to: "/profil" }, {
                default: _withCtx(() => [...(_cache[3] || (_cache[3] = [
                  _createTextVNode("Mina uppgifter", -1 /* CACHED */)
                ]))]),
                _: 1 /* STABLE */
              }),
              _createElementVNode("span", {
                class: "logout",
                onClick: $setup.logout
              }, "Logga ut")
            ])
          ])
        ]))
      : _createCommentVNode("v-if", true),
    _createElementVNode("main", _hoisted_3, [
      _createVNode(_component_RouterView)
    ])
  ]))
}

import "/src/App.vue?vue&type=style&index=0&lang.css"

_sfc_main.__hmrId = "7a7a37b1"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/Users/bonga/Desktop/CHAS Plugg/Projekt/Grupparbeten/Kraftly/Kraftly/Team-Ampere/src/App.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XHJcbiAgPGRpdj5cclxuICAgIDxoZWFkZXIgY2xhc3M9XCJ0b3BiYXJcIiB2LWlmPVwiJHJvdXRlLnBhdGggIT09ICcvbG9naW4nXCI+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJ0b3BiYXItaW5uZXIgY29udGFpbmVyXCI+XHJcbiAgICAgICAgPGltZyBzcmM9XCIuL2Fzc2V0cy9sb2dvLnN2Z1wiIGNsYXNzPVwibG9nb1wiPlxyXG4gICAgICAgIDxuYXY+XHJcbiAgICAgICAgICA8Um91dGVyTGluayB0bz1cIi9cIj7DlnZlcnNpa3Q8L1JvdXRlckxpbms+XHJcbiAgICAgICAgICA8Um91dGVyTGluayB0bz1cIi9mYWt0dXJvclwiPkZha3R1cm9yPC9Sb3V0ZXJMaW5rPlxyXG4gICAgICAgICAgPFJvdXRlckxpbmsgdG89XCIvZmx5dHRcIj5GbHl0dGFubcOkbGFuPC9Sb3V0ZXJMaW5rPlxyXG4gICAgICAgICAgPFJvdXRlckxpbmsgdG89XCIvcHJvZmlsXCI+TWluYSB1cHBnaWZ0ZXI8L1JvdXRlckxpbms+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzcz1cImxvZ291dFwiIEBjbGljaz1cImxvZ291dFwiPkxvZ2dhIHV0PC9zcGFuPlxyXG4gICAgICAgIDwvbmF2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvaGVhZGVyPlxyXG4gICAgPG1haW4gY2xhc3M9XCJjb250YWluZXJcIj5cclxuICAgICAgPFJvdXRlclZpZXcgLz5cclxuICAgIDwvbWFpbj5cclxuICA8L2Rpdj5cclxuPC90ZW1wbGF0ZT5cclxuXHJcbjxzY3JpcHQgc2V0dXA+XHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ3Z1ZS1yb3V0ZXInXHJcblxyXG5jb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKVxyXG5cclxuY29uc3QgbG9nb3V0ID0gKCkgPT4ge1xyXG4gIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdrcmFmdGx5X2xvZ2dlZF9pbicpXHJcbiAgcm91dGVyLnB1c2goJy9sb2dpbicpXHJcbn1cclxuPC9zY3JpcHQ+XHJcblxyXG48c3R5bGU+XHJcbi50b3BiYXIgeyBiYWNrZ3JvdW5kOiAjMTAxZDNkOyB9XHJcbi50b3BiYXItaW5uZXIgeyBkaXNwbGF5OiBmbGV4OyBhbGlnbi1pdGVtczogY2VudGVyOyBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47IHBhZGRpbmctdG9wOiAxNHB4OyBwYWRkaW5nLWJvdHRvbTogMTRweDsgfVxyXG4ubG9nbyB7IGhlaWdodDogMzBweDsgfVxyXG4udG9wYmFyIG5hdiBhLCAubG9nb3V0IHtcclxuICBjb2xvcjogI2MyY2JlNDtcclxuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgbWFyZ2luLWxlZnQ6IDIycHg7XHJcbiAgZm9udC1zaXplOiAxNC41cHg7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcbi50b3BiYXIgbmF2IGEucm91dGVyLWxpbmstYWN0aXZlIHsgY29sb3I6ICNmZmY7IGZvbnQtd2VpZ2h0OiA2MDA7IH1cclxuPC9zdHlsZT5cclxuIl0sIm1hcHBpbmdzIjoiQUFxQkEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDOzs7Ozs7QUFGYztBQUdkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQjtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQzs7Ozs7Ozs7Ozs7O0VBMUJXLEtBQUssRUFBQyxRQUFROztxQkFDZixLQUFLLEVBQUMsd0JBQXdCO3FCQVcvQixLQUFLLEVBQUMsV0FBVzs7Ozs7O3dCQWJ6QixvQkFnQk07S0FmeUIsV0FBTSxDQUFDLElBQUk7dUJBQXhDLG9CQVdTLFVBWFQsVUFXUztVQVZQLG9CQVNNLE9BVE4sVUFTTTtzQ0FSSixvQkFBMEM7Y0FBckMsR0FBRyxFQUFDLHNCQUFtQjtjQUFDLEtBQUssRUFBQyxNQUFNOztZQUN6QyxvQkFNTTtjQUxKLGFBQXdDLHlCQUE1QixFQUFFLEVBQUMsR0FBRztrQ0FBQyxDQUFRO21DQUFSLFVBQVE7Ozs7Y0FDM0IsYUFBZ0QseUJBQXBDLEVBQUUsRUFBQyxXQUFXO2tDQUFDLENBQVE7bUNBQVIsVUFBUTs7OztjQUNuQyxhQUFpRCx5QkFBckMsRUFBRSxFQUFDLFFBQVE7a0NBQUMsQ0FBWTttQ0FBWixjQUFZOzs7O2NBQ3BDLGFBQW9ELHlCQUF4QyxFQUFFLEVBQUMsU0FBUztrQ0FBQyxDQUFjO21DQUFkLGdCQUFjOzs7O2NBQ3ZDLG9CQUFvRDtnQkFBOUMsS0FBSyxFQUFDLFFBQVE7Z0JBQUUsT0FBSyxFQUFFLGFBQU07aUJBQUUsVUFBUTs7Ozs7SUFJbkQsb0JBRU8sUUFGUCxVQUVPO01BREwsYUFBYyIsImlnbm9yZUxpc3QiOltdfQ==