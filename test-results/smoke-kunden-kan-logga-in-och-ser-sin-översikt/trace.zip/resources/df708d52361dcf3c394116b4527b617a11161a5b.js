import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/ProfileView.vue");import { ref, onMounted } from "/node_modules/.vite/deps/vue.js?v=d70ec34b"
import AppButton from "/src/components/AppButton.vue"
import { useUserStore } from "/src/stores/user.js"


const _sfc_main = {
  __name: 'ProfileView',
  setup(__props, { expose: __expose }) {
  __expose();

const store = useUserStore()
const name = ref('')
const email = ref('')
const address = ref('')

const reset = () => {
  name.value = store.user.name
  email.value = store.user.email
  address.value = store.user.address
}

const save = () => {
  store.save({ name: name.value, email: email.value, address: address.value })
}

onMounted(async () => {
  if (!store.user) await store.load()
  reset()
})

const __returned__ = { store, name, email, address, reset, save, ref, onMounted, AppButton, get useUserStore() { return useUserStore } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createElementVNode as _createElementVNode, toDisplayString as _toDisplayString, vModelText as _vModelText, withDirectives as _withDirectives, createTextVNode as _createTextVNode, withCtx as _withCtx, createVNode as _createVNode, openBlock as _openBlock, createElementBlock as _createElementBlock, createCommentVNode as _createCommentVNode } from "/node_modules/.vite/deps/vue.js?v=d70ec34b"

const _hoisted_1 = {
  key: 0,
  class: "card",
  style: {"max-width":"560px"}
}
const _hoisted_2 = { class: "field" }

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("div", null, [
    _cache[5] || (_cache[5] = _createElementVNode("h1", null, "Mina uppgifter", -1 /* CACHED */)),
    ($setup.store.user)
      ? (_openBlock(), _createElementBlock("div", _hoisted_1, [
          _createElementVNode("div", _hoisted_2, [
            _cache[3] || (_cache[3] = _createElementVNode("span", { class: "field-label" }, "Kundnummer", -1 /* CACHED */)),
            _createElementVNode("span", null, _toDisplayString($setup.store.user.customerNo), 1 /* TEXT */)
          ]),
          _withDirectives(_createElementVNode("input", {
            type: "text",
            "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => (($setup.name) = $event))
          }, null, 512 /* NEED_PATCH */), [
            [_vModelText, $setup.name]
          ]),
          _withDirectives(_createElementVNode("input", {
            type: "text",
            "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => (($setup.email) = $event))
          }, null, 512 /* NEED_PATCH */), [
            [_vModelText, $setup.email]
          ]),
          _withDirectives(_createElementVNode("input", {
            type: "text",
            "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => (($setup.address) = $event))
          }, null, 512 /* NEED_PATCH */), [
            [_vModelText, $setup.address]
          ]),
          _createVNode($setup["AppButton"], {
            color: "#12b76a",
            onClick: $setup.save
          }, {
            default: _withCtx(() => [...(_cache[4] || (_cache[4] = [
              _createTextVNode("Spara ändringar", -1 /* CACHED */)
            ]))]),
            _: 1 /* STABLE */
          }),
          _createElementVNode("button", {
            class: "button-secondary",
            style: {"margin-left":"10px"},
            onClick: $setup.reset
          }, "Ångra")
        ]))
      : _createCommentVNode("v-if", true)
  ]))
}

import "/src/views/ProfileView.vue?vue&type=style&index=0&scoped=0e7a7305&lang.css"

_sfc_main.__hmrId = "0e7a7305"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-0e7a7305"],['__file',"C:/Users/bonga/Desktop/CHAS Plugg/Projekt/Grupparbeten/Kraftly/Kraftly/Team-Ampere/src/views/ProfileView.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUHJvZmlsZVZpZXcudnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjx0ZW1wbGF0ZT5cclxuICA8ZGl2PlxyXG4gICAgPGgxPk1pbmEgdXBwZ2lmdGVyPC9oMT5cclxuICAgIDxkaXYgY2xhc3M9XCJjYXJkXCIgc3R5bGU9XCJtYXgtd2lkdGg6NTYwcHhcIiB2LWlmPVwic3RvcmUudXNlclwiPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwiZmllbGRcIj5cclxuICAgICAgICA8c3BhbiBjbGFzcz1cImZpZWxkLWxhYmVsXCI+S3VuZG51bW1lcjwvc3Bhbj5cclxuICAgICAgICA8c3Bhbj57eyBzdG9yZS51c2VyLmN1c3RvbWVyTm8gfX08L3NwYW4+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiB2LW1vZGVsPVwibmFtZVwiPlxyXG4gICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiB2LW1vZGVsPVwiZW1haWxcIj5cclxuICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdi1tb2RlbD1cImFkZHJlc3NcIj5cclxuICAgICAgPEFwcEJ1dHRvbiBjb2xvcj1cIiMxMmI3NmFcIiBAY2xpY2s9XCJzYXZlXCI+U3BhcmEgw6RuZHJpbmdhcjwvQXBwQnV0dG9uPlxyXG4gICAgICA8YnV0dG9uIGNsYXNzPVwiYnV0dG9uLXNlY29uZGFyeVwiIHN0eWxlPVwibWFyZ2luLWxlZnQ6MTBweFwiIEBjbGljaz1cInJlc2V0XCI+w4VuZ3JhPC9idXR0b24+XHJcbiAgICA8L2Rpdj5cclxuICA8L2Rpdj5cclxuPC90ZW1wbGF0ZT5cclxuXHJcbjxzY3JpcHQgc2V0dXA+XHJcbmltcG9ydCB7IHJlZiwgb25Nb3VudGVkIH0gZnJvbSAndnVlJ1xyXG5pbXBvcnQgQXBwQnV0dG9uIGZyb20gJy4uL2NvbXBvbmVudHMvQXBwQnV0dG9uLnZ1ZSdcclxuaW1wb3J0IHsgdXNlVXNlclN0b3JlIH0gZnJvbSAnLi4vc3RvcmVzL3VzZXInXHJcblxyXG5jb25zdCBzdG9yZSA9IHVzZVVzZXJTdG9yZSgpXHJcbmNvbnN0IG5hbWUgPSByZWYoJycpXHJcbmNvbnN0IGVtYWlsID0gcmVmKCcnKVxyXG5jb25zdCBhZGRyZXNzID0gcmVmKCcnKVxyXG5cclxuY29uc3QgcmVzZXQgPSAoKSA9PiB7XHJcbiAgbmFtZS52YWx1ZSA9IHN0b3JlLnVzZXIubmFtZVxyXG4gIGVtYWlsLnZhbHVlID0gc3RvcmUudXNlci5lbWFpbFxyXG4gIGFkZHJlc3MudmFsdWUgPSBzdG9yZS51c2VyLmFkZHJlc3NcclxufVxyXG5cclxuY29uc3Qgc2F2ZSA9ICgpID0+IHtcclxuICBzdG9yZS5zYXZlKHsgbmFtZTogbmFtZS52YWx1ZSwgZW1haWw6IGVtYWlsLnZhbHVlLCBhZGRyZXNzOiBhZGRyZXNzLnZhbHVlIH0pXHJcbn1cclxuXHJcbm9uTW91bnRlZChhc3luYyAoKSA9PiB7XHJcbiAgaWYgKCFzdG9yZS51c2VyKSBhd2FpdCBzdG9yZS5sb2FkKClcclxuICByZXNldCgpXHJcbn0pXHJcbjwvc2NyaXB0PlxyXG5cclxuPHN0eWxlIHNjb3BlZD5cclxuLmZpZWxkIHsgZGlzcGxheTogZmxleDsganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuOyBwYWRkaW5nOiA4cHggMCAxNHB4OyBmb250LXNpemU6IDE0cHg7IH1cclxuLmZpZWxkLWxhYmVsIHsgY29sb3I6ICM3Yzg2OTg7IH1cclxuPC9zdHlsZT5cclxuIl0sIm1hcHBpbmdzIjoiQUFrQkEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0M7Ozs7OztBQUpjO0FBS2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCO0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUM7QUFDRDtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5RSxDQUFDO0FBQ0Q7QUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7O0VBckNPLEtBQUssRUFBQyxNQUFNO0VBQUMsS0FBdUIsRUFBdkIscUJBQXVCOztxQkFDbEMsS0FBSyxFQUFDLE9BQU87Ozt3QkFIdEIsb0JBYU07OEJBWkosb0JBQXVCLFlBQW5CLGdCQUFjO0tBQzhCLFlBQUssQ0FBQyxJQUFJO3VCQUExRCxvQkFVTSxPQVZOLFVBVU07VUFUSixvQkFHTSxPQUhOLFVBR007c0NBRkosb0JBQTJDLFVBQXJDLEtBQUssRUFBQyxhQUFhLElBQUMsWUFBVTtZQUNwQyxvQkFBd0MsK0JBQS9CLFlBQUssQ0FBQyxJQUFJLENBQUMsVUFBVTs7MEJBRWhDLG9CQUFrQztZQUEzQixJQUFJLEVBQUMsTUFBTTt5RUFBVSxXQUFJOzswQkFBSixXQUFJOzswQkFDaEMsb0JBQW1DO1lBQTVCLElBQUksRUFBQyxNQUFNO3lFQUFVLFlBQUs7OzBCQUFMLFlBQUs7OzBCQUNqQyxvQkFBcUM7WUFBOUIsSUFBSSxFQUFDLE1BQU07eUVBQVUsY0FBTzs7MEJBQVAsY0FBTzs7VUFDbkMsYUFBb0U7WUFBekQsS0FBSyxFQUFDLFNBQVM7WUFBRSxPQUFLLEVBQUUsV0FBSTs7OEJBQUUsQ0FBZTsrQkFBZixpQkFBZTs7OztVQUN4RCxvQkFBdUY7WUFBL0UsS0FBSyxFQUFDLGtCQUFrQjtZQUFDLEtBQXdCLEVBQXhCLHNCQUF3QjtZQUFFLE9BQUssRUFBRSxZQUFLO2FBQUUsT0FBSyIsImlnbm9yZUxpc3QiOltdfQ==