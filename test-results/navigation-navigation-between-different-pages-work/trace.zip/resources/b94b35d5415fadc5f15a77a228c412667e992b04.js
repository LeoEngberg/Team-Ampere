import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AppButton.vue");
// new button for the profile page, the old one couldn't be themed /J
// TODO merge with BaseButton some day
const _sfc_main = {
  name: 'AppButton',
  props: { color: { type: String, default: '#2f54eb' } }
}

import { renderSlot as _renderSlot, normalizeStyle as _normalizeStyle, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=403311fd"

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("button", {
    class: "app-btn",
    style: _normalizeStyle({ background: $props.color })
  }, [
    _renderSlot(_ctx.$slots, "default", {}, undefined, true)
  ], 4 /* STYLE */))
}

import "/src/components/AppButton.vue?vue&type=style&index=0&scoped=19765ba3&lang.css"

_sfc_main.__hmrId = "19765ba3"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-19765ba3"],['__file',"C:/Users/rwaqa/Desktop/Rabbiya repos/Team-Ampere/src/components/AppButton.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQzovVXNlcnMvcndhcWEvRGVza3RvcC9SYWJiaXlhIHJlcG9zL1RlYW0tQW1wZXJlL3NyYy9jb21wb25lbnRzL0FwcEJ1dHRvbi52dWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwQnV0dG9uLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XHJcbiAgPGJ1dHRvbiBjbGFzcz1cImFwcC1idG5cIiA6c3R5bGU9XCJ7IGJhY2tncm91bmQ6IGNvbG9yIH1cIj48c2xvdCAvPjwvYnV0dG9uPlxyXG48L3RlbXBsYXRlPlxyXG5cclxuPHNjcmlwdD5cclxuLy8gbmV3IGJ1dHRvbiBmb3IgdGhlIHByb2ZpbGUgcGFnZSwgdGhlIG9sZCBvbmUgY291bGRuJ3QgYmUgdGhlbWVkIC9KXHJcbi8vIFRPRE8gbWVyZ2Ugd2l0aCBCYXNlQnV0dG9uIHNvbWUgZGF5XHJcbmV4cG9ydCBkZWZhdWx0IHtcclxuICBuYW1lOiAnQXBwQnV0dG9uJyxcclxuICBwcm9wczogeyBjb2xvcjogeyB0eXBlOiBTdHJpbmcsIGRlZmF1bHQ6ICcjMmY1NGViJyB9IH1cclxufVxyXG48L3NjcmlwdD5cclxuXHJcbjxzdHlsZSBzY29wZWQ+XHJcbi5hcHAtYnRuIHsgYm9yZGVyOiAwOyBjb2xvcjogd2hpdGU7IHBhZGRpbmc6IDExcHggMjBweDsgYm9yZGVyLXJhZGl1czogOHB4OyBmb250LXNpemU6IDE1cHg7IGN1cnNvcjogcG9pbnRlcjsgfVxyXG48L3N0eWxlPlxyXG4iXSwibWFwcGluZ3MiOiI7QUFLQSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ3BFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtFQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFO0FBQ3ZEOzs7Ozt3QkFURSxvQkFBd0U7SUFBaEUsS0FBSyxFQUFDLFNBQVM7SUFBRSxLQUFLLGdDQUFnQixZQUFLOztJQUFJLFlBQVEiLCJpZ25vcmVMaXN0IjpbXX0=