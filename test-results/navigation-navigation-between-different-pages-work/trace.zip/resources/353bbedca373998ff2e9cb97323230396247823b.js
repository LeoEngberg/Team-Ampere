import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BaseButton.vue");const _sfc_main = {  }
import { createCommentVNode as _createCommentVNode, renderSlot as _renderSlot, createElementVNode as _createElementVNode, Fragment as _Fragment, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=403311fd"

const _hoisted_1 = { class: "btn" }

function _sfc_render(_ctx, _cache) {
  return (_openBlock(), _createElementBlock(_Fragment, null, [
    _createCommentVNode(" generic button, use this one! /M "),
    _createElementVNode("button", _hoisted_1, [
      _renderSlot(_ctx.$slots, "default")
    ])
  ], 2112 /* STABLE_FRAGMENT, DEV_ROOT_FRAGMENT */))
}


_sfc_main.__hmrId = "2d3a2488"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/Users/rwaqa/Desktop/Rabbiya repos/Team-Ampere/src/components/BaseButton.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQzovVXNlcnMvcndhcWEvRGVza3RvcC9SYWJiaXlhIHJlcG9zL1RlYW0tQW1wZXJlL3NyYy9jb21wb25lbnRzL0Jhc2VCdXR0b24udnVlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkJhc2VCdXR0b24udnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjx0ZW1wbGF0ZT5cclxuICA8IS0tIGdlbmVyaWMgYnV0dG9uLCB1c2UgdGhpcyBvbmUhIC9NIC0tPlxyXG4gIDxidXR0b24gY2xhc3M9XCJidG5cIj48c2xvdCAvPjwvYnV0dG9uPlxyXG48L3RlbXBsYXRlPlxyXG4iXSwibWFwcGluZ3MiOiI7OztxQkFFVSxLQUFLLEVBQUMsS0FBSzs7OztJQURuQix5REFBeUM7SUFDekMsb0JBQXFDLFVBQXJDLFVBQXFDO01BQWpCLFlBQVEiLCJpZ25vcmVMaXN0IjpbXX0=