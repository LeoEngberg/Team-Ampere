import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/MoveFormView.vue");import { ref, reactive } from "/node_modules/.vite/deps/vue.js?v=403311fd"
import BaseButton from "/src/components/BaseButton.vue"
import { submitMove } from "/src/services/api.js"


const _sfc_main = {
  __name: 'MoveFormView',
  setup(__props, { expose: __expose }) {
  __expose();

const form = reactive({ address: '', zip: '', city: '', date: '', contract: '' })
const reference = ref(null)

const submit = async () => {
  // TODO validation
  const res = await submitMove(form)
  reference.value = res.ref
}

const __returned__ = { form, reference, submit, ref, reactive, BaseButton, get submitMove() { return submitMove } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createElementVNode as _createElementVNode, vModelText as _vModelText, withDirectives as _withDirectives, vModelSelect as _vModelSelect, createTextVNode as _createTextVNode, withCtx as _withCtx, createVNode as _createVNode, toDisplayString as _toDisplayString, openBlock as _openBlock, createElementBlock as _createElementBlock, createCommentVNode as _createCommentVNode } from "/node_modules/.vite/deps/vue.js?v=403311fd"

const _hoisted_1 = {
  class: "card",
  style: {"max-width":"560px"}
}
const _hoisted_2 = {
  key: 0,
  style: {"color":"#12b76a","margin-top":"10px"}
}

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("div", null, [
    _cache[9] || (_cache[9] = _createElementVNode("h1", null, "Flyttanmälan", -1 /* CACHED */)),
    _createElementVNode("div", _hoisted_1, [
      _cache[7] || (_cache[7] = _createElementVNode("p", { style: {"margin-bottom":"14px"} }, "Fyll i uppgifterna nedan så flyttar vi ditt elavtal.", -1 /* CACHED */)),
      _withDirectives(_createElementVNode("input", {
        type: "text",
        placeholder: "Ny adress",
        "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => (($setup.form.address) = $event))
      }, null, 512 /* NEED_PATCH */), [
        [_vModelText, $setup.form.address]
      ]),
      _withDirectives(_createElementVNode("input", {
        type: "text",
        placeholder: "Postnummer",
        "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => (($setup.form.zip) = $event))
      }, null, 512 /* NEED_PATCH */), [
        [_vModelText, $setup.form.zip]
      ]),
      _withDirectives(_createElementVNode("input", {
        type: "text",
        placeholder: "Ort",
        "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => (($setup.form.city) = $event))
      }, null, 512 /* NEED_PATCH */), [
        [_vModelText, $setup.form.city]
      ]),
      _withDirectives(_createElementVNode("input", {
        type: "text",
        placeholder: "Inflyttningsdatum (ÅÅÅÅ-MM-DD)",
        "onUpdate:modelValue": _cache[3] || (_cache[3] = $event => (($setup.form.date) = $event))
      }, null, 512 /* NEED_PATCH */), [
        [_vModelText, $setup.form.date]
      ]),
      _withDirectives(_createElementVNode("select", {
        "onUpdate:modelValue": _cache[4] || (_cache[4] = $event => (($setup.form.contract) = $event))
      }, [...(_cache[5] || (_cache[5] = [
        _createElementVNode("option", {
          disabled: "",
          value: ""
        }, "Välj avtal", -1 /* CACHED */),
        _createElementVNode("option", null, "Rörligt pris", -1 /* CACHED */),
        _createElementVNode("option", null, "Fast pris 1 år", -1 /* CACHED */),
        _createElementVNode("option", null, "Fast pris 3 år", -1 /* CACHED */)
      ]))], 512 /* NEED_PATCH */), [
        [_vModelSelect, $setup.form.contract]
      ]),
      _createVNode($setup["BaseButton"], { onClick: $setup.submit }, {
        default: _withCtx(() => [...(_cache[6] || (_cache[6] = [
          _createTextVNode("Skicka flyttanmälan", -1 /* CACHED */)
        ]))]),
        _: 1 /* STABLE */
      }),
      _cache[8] || (_cache[8] = _createElementVNode("p", {
        class: "hint",
        style: {"margin-top":"8px"}
      }, "Anmälan måste göras senast 14 dagar före flytt", -1 /* CACHED */)),
      ($setup.reference)
        ? (_openBlock(), _createElementBlock("p", _hoisted_2, "Tack! Referensnummer: " + _toDisplayString($setup.reference), 1 /* TEXT */))
        : _createCommentVNode("v-if", true)
    ])
  ]))
}


_sfc_main.__hmrId = "f7675b52"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/Users/rwaqa/Desktop/Rabbiya repos/Team-Ampere/src/views/MoveFormView.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTW92ZUZvcm1WaWV3LnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XHJcbiAgPGRpdj5cclxuICAgIDxoMT5GbHl0dGFubcOkbGFuPC9oMT5cclxuICAgIDxkaXYgY2xhc3M9XCJjYXJkXCIgc3R5bGU9XCJtYXgtd2lkdGg6NTYwcHhcIj5cclxuICAgICAgPHAgc3R5bGU9XCJtYXJnaW4tYm90dG9tOjE0cHhcIj5GeWxsIGkgdXBwZ2lmdGVybmEgbmVkYW4gc8OlIGZseXR0YXIgdmkgZGl0dCBlbGF2dGFsLjwvcD5cclxuICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgcGxhY2Vob2xkZXI9XCJOeSBhZHJlc3NcIiB2LW1vZGVsPVwiZm9ybS5hZGRyZXNzXCI+XHJcbiAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHBsYWNlaG9sZGVyPVwiUG9zdG51bW1lclwiIHYtbW9kZWw9XCJmb3JtLnppcFwiPlxyXG4gICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cIk9ydFwiIHYtbW9kZWw9XCJmb3JtLmNpdHlcIj5cclxuICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgcGxhY2Vob2xkZXI9XCJJbmZseXR0bmluZ3NkYXR1bSAow4XDhcOFw4UtTU0tREQpXCIgdi1tb2RlbD1cImZvcm0uZGF0ZVwiPlxyXG4gICAgICA8c2VsZWN0IHYtbW9kZWw9XCJmb3JtLmNvbnRyYWN0XCI+XHJcbiAgICAgICAgPG9wdGlvbiBkaXNhYmxlZCB2YWx1ZT1cIlwiPlbDpGxqIGF2dGFsPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbj5Sw7ZybGlndCBwcmlzPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbj5GYXN0IHByaXMgMSDDpXI8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uPkZhc3QgcHJpcyAzIMOlcjwvb3B0aW9uPlxyXG4gICAgICA8L3NlbGVjdD5cclxuICAgICAgPEJhc2VCdXR0b24gQGNsaWNrPVwic3VibWl0XCI+U2tpY2thIGZseXR0YW5tw6RsYW48L0Jhc2VCdXR0b24+XHJcbiAgICAgIDxwIGNsYXNzPVwiaGludFwiIHN0eWxlPVwibWFyZ2luLXRvcDo4cHhcIj5Bbm3DpGxhbiBtw6VzdGUgZ8O2cmFzIHNlbmFzdCAxNCBkYWdhciBmw7ZyZSBmbHl0dDwvcD5cclxuICAgICAgPHAgdi1pZj1cInJlZmVyZW5jZVwiIHN0eWxlPVwiY29sb3I6IzEyYjc2YTttYXJnaW4tdG9wOjEwcHhcIj5UYWNrISBSZWZlcmVuc251bW1lcjoge3sgcmVmZXJlbmNlIH19PC9wPlxyXG4gICAgPC9kaXY+XHJcbiAgPC9kaXY+XHJcbjwvdGVtcGxhdGU+XHJcblxyXG48c2NyaXB0IHNldHVwPlxyXG5pbXBvcnQgeyByZWYsIHJlYWN0aXZlIH0gZnJvbSAndnVlJ1xyXG5pbXBvcnQgQmFzZUJ1dHRvbiBmcm9tICcuLi9jb21wb25lbnRzL0Jhc2VCdXR0b24udnVlJ1xyXG5pbXBvcnQgeyBzdWJtaXRNb3ZlIH0gZnJvbSAnLi4vc2VydmljZXMvYXBpJ1xyXG5cclxuY29uc3QgZm9ybSA9IHJlYWN0aXZlKHsgYWRkcmVzczogJycsIHppcDogJycsIGNpdHk6ICcnLCBkYXRlOiAnJywgY29udHJhY3Q6ICcnIH0pXHJcbmNvbnN0IHJlZmVyZW5jZSA9IHJlZihudWxsKVxyXG5cclxuY29uc3Qgc3VibWl0ID0gYXN5bmMgKCkgPT4ge1xyXG4gIC8vIFRPRE8gdmFsaWRhdGlvblxyXG4gIGNvbnN0IHJlcyA9IGF3YWl0IHN1Ym1pdE1vdmUoZm9ybSlcclxuICByZWZlcmVuY2UudmFsdWUgPSByZXMucmVmXHJcbn1cclxuPC9zY3JpcHQ+XHJcbiJdLCJtYXBwaW5ncyI6IkFBdUJBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVDOzs7Ozs7QUFKYztBQUtkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNCO0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQzs7Ozs7Ozs7Ozs7RUEvQlEsS0FBSyxFQUFDLE1BQU07RUFBQyxLQUF1QixFQUF2QixxQkFBdUI7Ozs7RUFjbkIsS0FBcUMsRUFBckMsdUNBQXFDOzs7O3dCQWhCN0Qsb0JBa0JNOzhCQWpCSixvQkFBcUIsWUFBakIsY0FBWTtJQUNoQixvQkFlTSxPQWZOLFVBZU07Z0NBZEosb0JBQXNGLE9BQW5GLEtBQTBCLEVBQTFCLHdCQUEwQixJQUFDLHNEQUFvRDtzQkFDbEYsb0JBQWtFO1FBQTNELElBQUksRUFBQyxNQUFNO1FBQUMsV0FBVyxFQUFDLFdBQVc7cUVBQVUsV0FBSSxDQUFDLE9BQU87O3NCQUFaLFdBQUksQ0FBQyxPQUFPOztzQkFDaEUsb0JBQStEO1FBQXhELElBQUksRUFBQyxNQUFNO1FBQUMsV0FBVyxFQUFDLFlBQVk7cUVBQVUsV0FBSSxDQUFDLEdBQUc7O3NCQUFSLFdBQUksQ0FBQyxHQUFHOztzQkFDN0Qsb0JBQXlEO1FBQWxELElBQUksRUFBQyxNQUFNO1FBQUMsV0FBVyxFQUFDLEtBQUs7cUVBQVUsV0FBSSxDQUFDLElBQUk7O3NCQUFULFdBQUksQ0FBQyxJQUFJOztzQkFDdkQsb0JBQW9GO1FBQTdFLElBQUksRUFBQyxNQUFNO1FBQUMsV0FBVyxFQUFDLGdDQUFnQztxRUFBVSxXQUFJLENBQUMsSUFBSTs7c0JBQVQsV0FBSSxDQUFDLElBQUk7O3NCQUNsRixvQkFLUztxRUFMUSxXQUFJLENBQUMsUUFBUTs7UUFDNUIsb0JBQTZDO1VBQXJDLFFBQVEsRUFBUixFQUFRO1VBQUMsS0FBSyxFQUFDLEVBQUU7V0FBQyxZQUFVO1FBQ3BDLG9CQUE2QixnQkFBckIsY0FBWTtRQUNwQixvQkFBK0IsZ0JBQXZCLGdCQUFjO1FBQ3RCLG9CQUErQixnQkFBdkIsZ0JBQWM7O3dCQUpQLFdBQUksQ0FBQyxRQUFROztNQU05QixhQUE0RCx3QkFBL0MsT0FBSyxFQUFFLGFBQU07MEJBQUUsQ0FBbUI7MkJBQW5CLHFCQUFtQjs7OztnQ0FDL0Msb0JBQXlGO1FBQXRGLEtBQUssRUFBQyxNQUFNO1FBQUMsS0FBc0IsRUFBdEIsb0JBQXNCO1NBQUMsZ0RBQThDO09BQzVFLGdCQUFTO3lCQUFsQixvQkFBbUcsS0FBbkcsVUFBbUcsRUFBekMsd0JBQXNCLG9CQUFHLGdCQUFTIiwiaWdub3JlTGlzdCI6W119