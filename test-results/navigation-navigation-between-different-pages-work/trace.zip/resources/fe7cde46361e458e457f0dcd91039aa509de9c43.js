import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/ProfileView.vue?vue&type=style&index=0&scoped=0e7a7305&lang.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "C:/Users/rwaqa/Desktop/Rabbiya repos/Team-Ampere/src/views/ProfileView.vue?vue&type=style&index=0&scoped=0e7a7305&lang.css"
const __vite__css = "\n.field[data-v-0e7a7305] { display: flex; justify-content: space-between; padding: 8px 0 14px; font-size: 14px;\n}\n.field-label[data-v-0e7a7305] { color: #7c8698;\n}\r\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))