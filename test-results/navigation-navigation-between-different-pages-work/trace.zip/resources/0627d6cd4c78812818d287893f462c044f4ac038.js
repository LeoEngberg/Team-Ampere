import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/LoginView.vue");import { ref } from "/node_modules/.vite/deps/vue.js?v=403311fd"
import { useRouter } from "/node_modules/.vite/deps/vue-router.js?v=403311fd"
import { login } from "/src/services/api.js"


const _sfc_main = {
  __name: 'LoginView',
  setup(__props, { expose: __expose }) {
  __expose();

const email = ref('')
const password = ref('')
const router = useRouter()

const handleLogin = async () => {
  // validation coming in v2 :)
  await login(email.value, password.value)
  localStorage.setItem('kraftly_logged_in', 'true')
  router.push('/')
}

const __returned__ = { email, password, router, handleLogin, ref, get useRouter() { return useRouter }, get login() { return login } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createElementVNode as _createElementVNode, vModelText as _vModelText, withDirectives as _withDirectives, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=403311fd"

const _hoisted_1 = { class: "login-wrap" }
const _hoisted_2 = { class: "card login-card" }

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("div", _hoisted_1, [
    _createElementVNode("div", _hoisted_2, [
      _cache[2] || (_cache[2] = _createElementVNode("img", {
        src: "/src/assets/logo-dark.svg",
        class: "login-logo"
      }, null, -1 /* CACHED */)),
      _cache[3] || (_cache[3] = _createElementVNode("h1", null, "Logga in på Mina sidor", -1 /* CACHED */)),
      _withDirectives(_createElementVNode("input", {
        type: "text",
        placeholder: "E-postadress",
        "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => (($setup.email) = $event))
      }, null, 512 /* NEED_PATCH */), [
        [_vModelText, $setup.email]
      ]),
      _withDirectives(_createElementVNode("input", {
        type: "password",
        placeholder: "Lösenord",
        "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => (($setup.password) = $event))
      }, null, 512 /* NEED_PATCH */), [
        [_vModelText, $setup.password]
      ]),
      _createElementVNode("button", {
        class: "btn",
        style: {"width":"100%"},
        onClick: $setup.handleLogin
      }, "Logga in"),
      _cache[4] || (_cache[4] = _createElementVNode("p", {
        class: "hint",
        style: {"margin-top":"10px"}
      }, "Problem att logga in? Ring kundservice 020-123 456", -1 /* CACHED */))
    ])
  ]))
}

import "/src/views/LoginView.vue?vue&type=style&index=0&scoped=45f5edd7&lang.css"

_sfc_main.__hmrId = "45f5edd7"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-45f5edd7"],['__file',"C:/Users/rwaqa/Desktop/Rabbiya repos/Team-Ampere/src/views/LoginView.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTG9naW5WaWV3LnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XHJcbiAgPGRpdiBjbGFzcz1cImxvZ2luLXdyYXBcIj5cclxuICAgIDxkaXYgY2xhc3M9XCJjYXJkIGxvZ2luLWNhcmRcIj5cclxuICAgICAgPGltZyBzcmM9XCIuLi9hc3NldHMvbG9nby1kYXJrLnN2Z1wiIGNsYXNzPVwibG9naW4tbG9nb1wiPlxyXG4gICAgICA8aDE+TG9nZ2EgaW4gcMOlIE1pbmEgc2lkb3I8L2gxPlxyXG4gICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cIkUtcG9zdGFkcmVzc1wiIHYtbW9kZWw9XCJlbWFpbFwiPlxyXG4gICAgICA8aW5wdXQgdHlwZT1cInBhc3N3b3JkXCIgcGxhY2Vob2xkZXI9XCJMw7ZzZW5vcmRcIiB2LW1vZGVsPVwicGFzc3dvcmRcIj5cclxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0blwiIHN0eWxlPVwid2lkdGg6MTAwJVwiIEBjbGljaz1cImhhbmRsZUxvZ2luXCI+TG9nZ2EgaW48L2J1dHRvbj5cclxuICAgICAgPHAgY2xhc3M9XCJoaW50XCIgc3R5bGU9XCJtYXJnaW4tdG9wOjEwcHhcIj5Qcm9ibGVtIGF0dCBsb2dnYSBpbj8gUmluZyBrdW5kc2VydmljZSAwMjAtMTIzIDQ1NjwvcD5cclxuICAgIDwvZGl2PlxyXG4gIDwvZGl2PlxyXG48L3RlbXBsYXRlPlxyXG5cclxuPHNjcmlwdCBzZXR1cD5cclxuaW1wb3J0IHsgcmVmIH0gZnJvbSAndnVlJ1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICd2dWUtcm91dGVyJ1xyXG5pbXBvcnQgeyBsb2dpbiB9IGZyb20gJy4uL3NlcnZpY2VzL2FwaSdcclxuXHJcbmNvbnN0IGVtYWlsID0gcmVmKCcnKVxyXG5jb25zdCBwYXNzd29yZCA9IHJlZignJylcclxuY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKClcclxuXHJcbmNvbnN0IGhhbmRsZUxvZ2luID0gYXN5bmMgKCkgPT4ge1xyXG4gIC8vIHZhbGlkYXRpb24gY29taW5nIGluIHYyIDopXHJcbiAgYXdhaXQgbG9naW4oZW1haWwudmFsdWUsIHBhc3N3b3JkLnZhbHVlKVxyXG4gIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdrcmFmdGx5X2xvZ2dlZF9pbicsICd0cnVlJylcclxuICByb3V0ZXIucHVzaCgnLycpXHJcbn1cclxuPC9zY3JpcHQ+XHJcblxyXG48c3R5bGUgc2NvcGVkPlxyXG4ubG9naW4td3JhcCB7IGRpc3BsYXk6IGZsZXg7IGp1c3RpZnktY29udGVudDogY2VudGVyOyBwYWRkaW5nLXRvcDogNjBweDsgfVxyXG4ubG9naW4tY2FyZCB7IHdpZHRoOiAzODBweDsgfVxyXG4ubG9naW4tbG9nbyB7IGhlaWdodDogMzRweDsgbWFyZ2luLWJvdHRvbTogMThweDsgfVxyXG48L3N0eWxlPlxyXG4iXSwibWFwcGluZ3MiOiJBQWNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZDOzs7Ozs7QUFKYztBQUtkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQjtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQzs7Ozs7Ozs7OztxQkExQk0sS0FBSyxFQUFDLFlBQVk7cUJBQ2hCLEtBQUssRUFBQyxpQkFBaUI7Ozt3QkFEOUIsb0JBU00sT0FUTixVQVNNO0lBUkosb0JBT00sT0FQTixVQU9NO2dDQU5KLG9CQUFzRDtRQUFqRCxHQUFHLEVBQUMsMkJBQXlCO1FBQUMsS0FBSyxFQUFDLFlBQVk7O2dDQUNyRCxvQkFBK0IsWUFBM0Isd0JBQXNCO3NCQUMxQixvQkFBOEQ7UUFBdkQsSUFBSSxFQUFDLE1BQU07UUFBQyxXQUFXLEVBQUMsY0FBYztxRUFBVSxZQUFLOztzQkFBTCxZQUFLOztzQkFDNUQsb0JBQWlFO1FBQTFELElBQUksRUFBQyxVQUFVO1FBQUMsV0FBVyxFQUFDLFVBQVU7cUVBQVUsZUFBUTs7c0JBQVIsZUFBUTs7TUFDL0Qsb0JBQTZFO1FBQXJFLEtBQUssRUFBQyxLQUFLO1FBQUMsS0FBa0IsRUFBbEIsZ0JBQWtCO1FBQUUsT0FBSyxFQUFFLGtCQUFXO1NBQUUsVUFBUTtnQ0FDcEUsb0JBQThGO1FBQTNGLEtBQUssRUFBQyxNQUFNO1FBQUMsS0FBdUIsRUFBdkIscUJBQXVCO1NBQUMsb0RBQWtEIiwiaWdub3JlTGlzdCI6W119